class Translation {
  final String originalText;
  final String translatedText;

  Translation({required this.originalText, required this.translatedText});
}