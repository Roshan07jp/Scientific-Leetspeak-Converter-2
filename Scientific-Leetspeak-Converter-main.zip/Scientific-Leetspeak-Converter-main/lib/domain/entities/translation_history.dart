import 'package:scientific_leetspeak_app/domain/entities/translation.dart';

class TranslationHistory {
  final List<Translation> translations;

  TranslationHistory({required this.translations});
}