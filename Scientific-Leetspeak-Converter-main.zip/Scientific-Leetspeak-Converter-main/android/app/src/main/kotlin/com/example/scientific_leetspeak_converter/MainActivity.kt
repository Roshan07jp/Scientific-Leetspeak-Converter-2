package com.example.scientific_leetspeak_converter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
